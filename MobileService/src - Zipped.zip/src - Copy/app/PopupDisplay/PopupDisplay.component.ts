import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-PopupDisplay',
  templateUrl: './PopupDisplay.component.html',
  styleUrls: ['./PopupDisplay.component.css']
})
export class PopupDisplayComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
